﻿using Microsoft.Win32;
using Siemens.Engineering;
using Siemens.Engineering.Compiler;
using Siemens.Engineering.Hmi;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Features;
using Siemens.Engineering.SW;
using Siemens.Engineering.SW.Blocks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.WindowsAPICodePack.Dialogs;
using Siemens.Engineering.Cax;

namespace StartOpenness
{
    public partial class Form1 : Form
    {

        private static TiaPortalProcess _tiaProcess;

        public TiaPortal MyTiaPortal
        {
            get; set;
        }
        public Project MyProject
        {
            get; set;
        }


        public Form1()
        {
            InitializeComponent();
            AppDomain CurrentDomain = AppDomain.CurrentDomain;
            CurrentDomain.AssemblyResolve += new ResolveEventHandler(MyResolver);
        }

        private static Assembly MyResolver(object sender, ResolveEventArgs args)
        {
            int index = args.Name.IndexOf(',');
            if (index == -1)
            {
                return null;
            }
            string name = args.Name.Substring(0, index);

            RegistryKey filePathReg = Registry.LocalMachine.OpenSubKey(
                "SOFTWARE\\Siemens\\Automation\\Openness\\15.1\\PublicAPI\\15.1.0.0");

            if (filePathReg == null)
                return null;

            object oRegKeyValue = filePathReg.GetValue(name);
            if (oRegKeyValue != null)
            {
                string filePath = oRegKeyValue.ToString();

                string path = filePath;
                string fullPath = Path.GetFullPath(path);
                if (File.Exists(fullPath))
                {
                    return Assembly.LoadFrom(fullPath);
                }
            }

            return null;
        }


        private void StartTIA(object sender, EventArgs e)
        {
            if (rdb_WithoutUI.Checked == true)
            {
                MyTiaPortal = new TiaPortal(TiaPortalMode.WithoutUserInterface);
                txt_Status.Text = "TIA Portal started without user interface";
                _tiaProcess = TiaPortal.GetProcesses()[0];
            }
            else
            {
                MyTiaPortal = new TiaPortal(TiaPortalMode.WithUserInterface);
                txt_Status.Text = "TIA Portal started with user interface";
            }

            btn_SearchProject.Enabled = true;
            btn_Dispose.Enabled = true;
            btn_Start.Enabled = false;

        }

        private void DisposeTIA(object sender, EventArgs e)
        {
            MyTiaPortal.Dispose();
            txt_Status.Text = "TIA Portal disposed";

            btn_Start.Enabled = true;
            btn_Dispose.Enabled = false;
            btn_CloseProject.Enabled = false;
            btn_SearchProject.Enabled = false;
            btn_CompileHW.Enabled = false;
            btn_Save.Enabled = false;


        }

        private void SearchProject(object sender, EventArgs e)
        {

            OpenFileDialog fileSearch = new OpenFileDialog();

            fileSearch.Filter = "*.ap15_1|*.ap15_1";
            fileSearch.RestoreDirectory = true;
            fileSearch.ShowDialog();

            string ProjectPath = fileSearch.FileName.ToString();

            if (string.IsNullOrEmpty(ProjectPath) == false)
            {
                OpenProject(ProjectPath);
            }
        }

        private void OpenProject(string ProjectPath)
        {
            try
            {
                MyProject = MyTiaPortal.Projects.Open(new FileInfo(ProjectPath));
                txt_Status.Text = "Project " + ProjectPath + " opened";

            }
            catch (Exception ex)
            {
                txt_Status.Text = "Error while opening project" + ex.Message;
            }

            btn_CompileHW.Enabled = true;
            btn_CloseProject.Enabled = true;
            btn_SearchProject.Enabled = false;
            btn_Save.Enabled = true;
            btn_AddHW.Enabled = true;
        }

        private void SaveProject(object sender, EventArgs e)
        {
            MyProject.Save();
            txt_Status.Text = "Project saved";
        }


        private void CloseProject(object sender, EventArgs e)
        {
            MyProject.Close();

            txt_Status.Text = "Project closed";

            btn_SearchProject.Enabled = true;
            btn_CloseProject.Enabled = false;
            btn_Save.Enabled = false;
            btn_CompileHW.Enabled = false;


        }

        private void Compile(object sender, EventArgs e)
        {
            btn_CompileHW.Enabled = false;

            string devname = txt_Device.Text;
            bool found = false;

            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    if (deviceItem.Name == devname || device.Name == devname)
                    {
                        SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                        if (softwareContainer != null)
                        {
                            if (softwareContainer.Software is PlcSoftware)
                            {
                                PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                                if (controllerTarget != null)
                                {
                                    found = true;
                                    ICompilable compiler = controllerTarget.GetService<ICompilable>();

                                    CompilerResult result = compiler.Compile();
                                    txt_Status.Text = "Compiling of " + controllerTarget.Name + ": State: " + result.State + " / Warning Count: " + result.WarningCount + " / Error Count: " + result.ErrorCount;

                                }
                            }
                            if (softwareContainer.Software is HmiTarget)
                            {
                                HmiTarget hmitarget = softwareContainer.Software as HmiTarget;
                                if (hmitarget != null)
                                {
                                    found = true;
                                    ICompilable compiler = hmitarget.GetService<ICompilable>();
                                    CompilerResult result = compiler.Compile();
                                    txt_Status.Text = "Compiling of " + hmitarget.Name + ": State: " + result.State + " / Warning Count: " + result.WarningCount + " / Error Count: " + result.ErrorCount;
                                }

                            }
                        }
                    }
                }
            }
            if (found == false)
            {
                txt_Status.Text = "Found no device with name " + txt_Device.Text;
            }

            btn_CompileHW.Enabled = true;
        }

        private void btn_AddHW_Click(object sender, EventArgs e)
        {
            btn_AddHW.Enabled = false;
            string MLFB = "OrderNumber:" + txt_OrderNo.Text + "/" + txt_Version.Text;

            string name = txt_AddDevice.Text;
            string devname = "station" + txt_AddDevice.Text;
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    if (deviceItem.Name == devname || device.Name == devname)
                    {
                        SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                        if (softwareContainer != null)
                        {
                            if (softwareContainer.Software is PlcSoftware)
                            {
                                PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                                if (controllerTarget != null)
                                {
                                    found = true;

                                }
                            }
                            if (softwareContainer.Software is HmiTarget)
                            {
                                HmiTarget hmitarget = softwareContainer.Software as HmiTarget;
                                if (hmitarget != null)
                                {
                                    found = true;

                                }

                            }
                        }
                    }
                }
            }
            if (found == true)
            {
                txt_Status.Text = "Device " + txt_Device.Text + " already exists";
            }
            else
            {
                Device deviceName = MyProject.Devices.CreateWithItem(MLFB, name, devname);

                txt_Status.Text = "Add Device Name: " + name + " with Order Number: " + txt_OrderNo.Text + " and Firmware Version: " + txt_Version.Text;
            }

            btn_AddHW.Enabled = true;

        }

        private void btn_ConnectTIA(object sender, EventArgs e)
        {
            btn_Connect.Enabled = false;
            IList<TiaPortalProcess> processes = TiaPortal.GetProcesses();
            switch (processes.Count)
            {
                case 1:
                    _tiaProcess = processes[0];
                    MyTiaPortal = _tiaProcess.Attach();
                    if (MyTiaPortal.GetCurrentProcess().Mode == TiaPortalMode.WithUserInterface)
                    {
                        rdb_WithUI.Checked = true;
                    }
                    else
                    {
                        rdb_WithoutUI.Checked = true;
                    }


                    if (MyTiaPortal.Projects.Count <= 0)
                    {
                        txt_Status.Text = "No TIA Portal Project was found!";
                        btn_Connect.Enabled = true;
                        return;
                    }
                    MyProject = MyTiaPortal.Projects[0];
                    break;
                case 0:
                    txt_Status.Text = "No running instance of TIA Portal was found!";
                    btn_Connect.Enabled = true;
                    return;
                default:
                    txt_Status.Text = "More than one running instance of TIA Portal was found!";
                    btn_Connect.Enabled = true;
                    return;
            }
            txt_Status.Text = _tiaProcess.ProjectPath.ToString();
            btn_Start.Enabled = false;
            btn_Connect.Enabled = true;
            btn_Dispose.Enabled = true;
            btn_CompileHW.Enabled = true;
            btn_CloseProject.Enabled = true;
            btn_SearchProject.Enabled = false;
            btn_Save.Enabled = true;
            btn_AddHW.Enabled = true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button_CreateFolder_Click(object sender, EventArgs e)
        {
            string n_grp = txtBox_FolderName.Text;
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                    if (softwareContainer != null)
                    {
                        if (softwareContainer.Software is PlcSoftware)
                        {
                            PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                            if (controllerTarget != null)
                            {
                                found = true;

                                bool found2 = false;
                                if (found == true)
                                {
                                    PlcBlockSystemGroup systemGroup = controllerTarget.BlockGroup;
                                    PlcBlockUserGroupComposition groupComposition = systemGroup.Groups;
                                    foreach (PlcBlockUserGroup myCreatedGroup in groupComposition)
                                    {
                                        if (myCreatedGroup.Name == n_grp)
                                        {
                                            found2 = true;
                                        }
                                    }

                                    if (found2 == true)
                                    {
                                        txt_Status.Text = "Folder " + txtBox_FolderName.Text + " already exists";
                                    }
                                    else
                                    {
                                        PlcBlockUserGroup myCreatedGroup = groupComposition.Create(n_grp);
                                        txt_Status.Text = "Folder " + txtBox_FolderName.Text + " added";
                                    }

                                }

                            }
                        }
                    }
                }


            }

        }

        private void button_AddBlock_Click(object sender, EventArgs e)
        {
            //string n_block = textBox3.Text;
            

            string n_grp = txtBox_FolderName.Text;
            bool found = false;

            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                    if (softwareContainer != null)
                    {
                        if (softwareContainer.Software is PlcSoftware)
                        {
                            PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                            if (controllerTarget != null)
                            {
                                found = true;

                                bool found2 = false;
                                if (found == true)
                                {
                                    PlcBlockSystemGroup systemGroup = controllerTarget.BlockGroup;
                                    PlcBlockUserGroupComposition groupComposition = systemGroup.Groups;
                                    foreach (PlcBlockUserGroup myCreatedGroup in groupComposition)
                                    {
                                        if (myCreatedGroup.Name == n_grp)
                                        {
                                            found2 = true;
                                        }
                                    }

                                    if (found2 == true)
                                    {

                                        PlcBlockUserGroup myCreatedGroup = groupComposition.Find(n_grp);

                                        if (myCreatedGroup != null)
                                        {

                                            PlcBlockComposition plcBlockComposition = myCreatedGroup.Blocks;
                                            if (plcBlockComposition != null)
                                            {
                                                string fbName = textBox3.Text;
                                                bool isAutoNumber = true;
                                                int number = 1;
                                                var progLang = ProgrammingLanguage.ProDiag;
                                                FB block = plcBlockComposition.CreateFB(fbName, isAutoNumber, number, progLang);
                                                string iDBName = textBox3.Text+"_IDB";
                                                string instanceOfName = fbName;
                                                InstanceDB iDbBlock = plcBlockComposition.CreateInstanceDB(iDBName, isAutoNumber, number, instanceOfName);
                                            }
                                            txt_Status.Text = "Block " + textBox3.Text + " is added in" + txtBox_FolderName.Text;
                                        }

                                    }
                                    else
                                    {
                                        PlcBlockUserGroup myCreatedGroup = groupComposition.Create(n_grp);

                                        PlcBlockComposition plcBlockComposition = myCreatedGroup.Blocks;
                                        if (plcBlockComposition != null)
                                        {
                                            string fbName = textBox3.Text;
                                            bool isAutoNumber = true;
                                            int number = 1;
                                            var progLang = ProgrammingLanguage.ProDiag;
                                            FB block = plcBlockComposition.CreateFB(fbName, isAutoNumber, number, progLang);
                                            string iDBName = textBox3.Text + "_IDB";
                                            string instanceOfName = fbName;
                                            InstanceDB iDbBlock = plcBlockComposition.CreateInstanceDB(iDBName, isAutoNumber, number, instanceOfName);
                                        }

                                        txt_Status.Text = "Block " + textBox3.Text + " is added in" + txtBox_FolderName.Text;
                                    }

                                }

                            }
                        }
                    }
                }


            }

        }

        private void button_SearchFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            
            openFileDialog1.Multiselect = true;
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Database files (*.xml)|*.xml";
            openFileDialog1.FilterIndex = 0;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                foreach (string file in openFileDialog1.FileNames)
                {
                    FileInfo fi = new FileInfo(file);
                    ListViewItem lst = new ListViewItem(fi.FullName);
                    listView1.Items.Add(lst);
                    
                }
                //textBox_FilePath.Text = openFileDialog1.FileName;
                
            }
        }

        private void button_Import_Click(object sender, EventArgs e)
        {
            string n_grp = txtBox_FolderName.Text;
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                    if (softwareContainer != null)
                    {
                        if (softwareContainer.Software is PlcSoftware)
                        {
                            PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                            if (controllerTarget != null)
                            {
                                found = true;

                                bool found2 = false;
                                if (found == true)
                                {
                                    PlcBlockSystemGroup systemGroup = controllerTarget.BlockGroup;
                                    PlcBlockUserGroupComposition groupComposition = systemGroup.Groups;
                                    foreach (PlcBlockUserGroup myCreatedGroup in groupComposition)
                                    {
                                        if (myCreatedGroup.Name == n_grp)
                                        {
                                            found2 = true;
                                        }
                                    }

                                    if (found2 == true)
                                    {

                                        PlcBlockUserGroup myCreatedGroup = groupComposition.Find(n_grp);

                                        if (myCreatedGroup != null)
                                        {

                                            PlcBlockComposition plcBlockComposition = myCreatedGroup.Blocks;
                                            if (plcBlockComposition != null)
                                            {
                                                IList<PlcBlock> blocks = myCreatedGroup.Blocks.Import(new FileInfo(listView1.Text), ImportOptions.Override);

                                            }
                                            txt_Status.Text = "Block is added in" + txtBox_FolderName.Text;
                                        }

                                    }
                                    else
                                    {
                                        PlcBlockSystemGroup systemblockGroup = controllerTarget.BlockGroup;
                                        IList<PlcBlock> blocks = systemblockGroup.Blocks.Import(new FileInfo(listView1.Text), ImportOptions.Override);


                                        txt_Status.Text = "Block is added without folder";
                                    }

                                }

                            }
                        }
                    }
                }


            }
        }

        private void button_EplanExport_Click(object sender, EventArgs e)
        {
            //.Open(new FileInfo(_tiaProcess.ProjectPath.DirectoryName));
            CaxProvider caxProvider = MyProject.GetService<CaxProvider>();
            if (caxProvider != null)
            {
                caxProvider.Export(MyProject, new FileInfo(@"C:\Users\HLS Admin\Desktop\MasterThesis\" + textBox_EplanExport.Text+".aml"),new FileInfo(@"C:\Users\HLS Admin\Desktop\MasterThesis\" + textBox_EplanExport.Text + "_Log.log"));

            }
        }

        private void button_AddEplan_Click(object sender, EventArgs e)
        {
            //Access the CaxProvider service
            //Project project = tiaPortal.Projects.Open(...);
            CaxProvider caxProvider = MyProject.GetService<CaxProvider>();
            if (caxProvider != null)
            {
                // Perform Cax export and import operation
                caxProvider.Import(new FileInfo(textBox1.Text), new FileInfo(textBox2.Text), CaxImportOptions.MoveToParkingLot);
            }
        }

        private void button_Brows_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Database files (*.aml)|*.aml";
            openFileDialog1.FilterIndex = 0;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = openFileDialog1.FileName;
            }
        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Database files (*.log)|*.log";
            openFileDialog1.FilterIndex = 0;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = openFileDialog1.FileName;

            }
        }


        //Exports a regular block
       


        private void button_Export_Click(object sender, EventArgs e)
        {
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                    if (softwareContainer != null)
                    {
                        if (softwareContainer.Software is PlcSoftware)
                        {
                            PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                            if (controllerTarget != null)
                            {
                                found = true;

                                bool found2 = false;
                                if (found == true)
                                {

                                    foreach (PlcBlock plcBlock in controllerTarget.BlockGroup.Blocks)
                                    {
                                        if (plcBlock.Name == textBox_ExportName.Text)
                                        {
                                            found2 = true;
                                        }
                                        
                                    }

                                    if (found2 == true)
                                    {
                                        try
                                        {
                                            //Exports a regular block
                                            PlcBlock plcBlock = controllerTarget.BlockGroup.Blocks.Find(textBox_ExportName.Text);
                                            plcBlock.Export(new FileInfo(string.Format(@"C:\Desktop\" + textBox_ExportName.Text + ".xml", plcBlock.Name)), ExportOptions.WithDefaults);
                                            txt_Status.Text = "Block " + textBox_ExportName.Text + " is added";
                                        }
                                        

                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Opss: " + ex.Message);
                                        }
                                    }
                                }
                                
                                else
                                {
                                    txt_Status.Text = "There is no block with name " + textBox_ExportName.Text;
                                }
                            }
                        }
                    }
                }


            }
            
        }

        private void button1_2_Click(object sender, EventArgs e)
        {
            string n_grp = txtBox_FolderName.Text;
            string n_grp2 = textBox4_2.Text;
            bool found = false;
            foreach (Device device in MyProject.Devices)
            {
                DeviceItemComposition deviceItemAggregation = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemAggregation)
                {
                    SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                    if (softwareContainer != null)
                    {
                        if (softwareContainer.Software is PlcSoftware)
                        {
                            PlcSoftware controllerTarget = softwareContainer.Software as PlcSoftware;
                            if (controllerTarget != null)
                            {
                                found = true;

                                bool found2 = false;
                                if (found == true)
                                {
                                    PlcBlockSystemGroup systemGroup = controllerTarget.BlockGroup;
                                    PlcBlockUserGroupComposition groupComposition = systemGroup.Groups;
                                    foreach (PlcBlockUserGroup myCreatedGroup in groupComposition)
                                    {
                                        if (myCreatedGroup.Name == n_grp)
                                        {
                                            found2 = true;
                                        }
                                    }

                                    bool found3 = false;
                                    if (found2 == true)
                                    {

                                        PlcBlockUserGroup myCreatedGroup = groupComposition.Find(n_grp);

                                        if (myCreatedGroup != null)
                                        {

                                            foreach (PlcBlockUserGroup myCreatedGroup2 in groupComposition)
                                            {
                                                if (myCreatedGroup2.Name == n_grp2)
                                                {
                                                    found3 = true;
                                                }
                                            }

                                            if (found3 == true)
                                            {
                                                txt_Status.Text = "Folder: " + textBox4_2.Text + " is akready existed under " + txtBox_FolderName.Text;
                                            }

                                            else
                                            {
                                                try
                                                {
                                                    PlcBlockUserGroup myCreatedGroup2 = groupComposition.Create(n_grp2);

                                                    txt_Status.Text = "Folder:" + textBox4_2.Text + " is added under" + txtBox_FolderName.Text;
                                                }

                                                catch (Exception ex)
                                                {
                                                    MessageBox.Show(ex.Message);
                                                }
                                            }
                                        }
                                    }
                                   

                                }

                            }
                        }
                    }
                }


            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void removeSelectedFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count != 0)
            {
                foreach (ListViewItem lst in listView1.SelectedItems)
                    lst.Remove();
            }
        }

        private void remove_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }
    }
}
