﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
using System.Reflection;
using System.IO;

namespace StartOpenness
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_Start = new System.Windows.Forms.Button();
            this.btn_Dispose = new System.Windows.Forms.Button();
            this.btn_SearchProject = new System.Windows.Forms.Button();
            this.txt_Status = new System.Windows.Forms.TextBox();
            this.btn_CloseProject = new System.Windows.Forms.Button();
            this.btn_CompileHW = new System.Windows.Forms.Button();
            this.txt_Device = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_TIA = new System.Windows.Forms.GroupBox();
            this.rdb_WithoutUI = new System.Windows.Forms.RadioButton();
            this.rdb_WithUI = new System.Windows.Forms.RadioButton();
            this.grp_Compile = new System.Windows.Forms.GroupBox();
            this.grp_Project = new System.Windows.Forms.GroupBox();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.btn_AddHW = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_Version = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_OrderNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_AddDevice = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_BrowsAML = new System.Windows.Forms.Button();
            this.button_AddEplan = new System.Windows.Forms.Button();
            this.label_Eplan = new System.Windows.Forms.Label();
            this.label_FolderName = new System.Windows.Forms.Label();
            this.txtBox_FolderName = new System.Windows.Forms.TextBox();
            this.button_CreateFolder = new System.Windows.Forms.Button();
            this.label_BlockName = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button_AddBlock = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_BrowsLog = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1_2 = new System.Windows.Forms.Button();
            this.textBox4_2 = new System.Windows.Forms.TextBox();
            this.button_Export = new System.Windows.Forms.Button();
            this.textBox_ExportName = new System.Windows.Forms.TextBox();
            this.button_SearchFile = new System.Windows.Forms.Button();
            this.button_Import = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_EplanExport = new System.Windows.Forms.TextBox();
            this.button_EplanExport = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.remove = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.removeSelectedFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grp_TIA.SuspendLayout();
            this.grp_Compile.SuspendLayout();
            this.grp_Project.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.remove.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Start
            // 
            this.btn_Start.Location = new System.Drawing.Point(36, 85);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(115, 36);
            this.btn_Start.TabIndex = 0;
            this.btn_Start.Text = "Start TIA";
            this.btn_Start.UseVisualStyleBackColor = true;
            this.btn_Start.Click += new System.EventHandler(this.StartTIA);
            // 
            // btn_Dispose
            // 
            this.btn_Dispose.Enabled = false;
            this.btn_Dispose.Location = new System.Drawing.Point(36, 140);
            this.btn_Dispose.Name = "btn_Dispose";
            this.btn_Dispose.Size = new System.Drawing.Size(115, 36);
            this.btn_Dispose.TabIndex = 4;
            this.btn_Dispose.Text = "Dispose TIA";
            this.btn_Dispose.UseVisualStyleBackColor = true;
            this.btn_Dispose.Click += new System.EventHandler(this.DisposeTIA);
            // 
            // btn_SearchProject
            // 
            this.btn_SearchProject.Enabled = false;
            this.btn_SearchProject.Location = new System.Drawing.Point(38, 23);
            this.btn_SearchProject.Name = "btn_SearchProject";
            this.btn_SearchProject.Size = new System.Drawing.Size(115, 36);
            this.btn_SearchProject.TabIndex = 5;
            this.btn_SearchProject.Text = "Open Project";
            this.btn_SearchProject.UseVisualStyleBackColor = true;
            this.btn_SearchProject.Click += new System.EventHandler(this.SearchProject);
            // 
            // txt_Status
            // 
            this.txt_Status.BackColor = System.Drawing.SystemColors.Menu;
            this.txt_Status.Location = new System.Drawing.Point(12, 242);
            this.txt_Status.Name = "txt_Status";
            this.txt_Status.Size = new System.Drawing.Size(761, 20);
            this.txt_Status.TabIndex = 7;
            // 
            // btn_CloseProject
            // 
            this.btn_CloseProject.Enabled = false;
            this.btn_CloseProject.Location = new System.Drawing.Point(38, 152);
            this.btn_CloseProject.Name = "btn_CloseProject";
            this.btn_CloseProject.Size = new System.Drawing.Size(115, 36);
            this.btn_CloseProject.TabIndex = 8;
            this.btn_CloseProject.Text = "Close Project";
            this.btn_CloseProject.UseVisualStyleBackColor = true;
            this.btn_CloseProject.Click += new System.EventHandler(this.CloseProject);
            // 
            // btn_CompileHW
            // 
            this.btn_CompileHW.Enabled = false;
            this.btn_CompileHW.Location = new System.Drawing.Point(37, 85);
            this.btn_CompileHW.Name = "btn_CompileHW";
            this.btn_CompileHW.Size = new System.Drawing.Size(115, 36);
            this.btn_CompileHW.TabIndex = 12;
            this.btn_CompileHW.Text = "Compile";
            this.btn_CompileHW.UseVisualStyleBackColor = true;
            this.btn_CompileHW.Click += new System.EventHandler(this.Compile);
            // 
            // txt_Device
            // 
            this.txt_Device.Location = new System.Drawing.Point(37, 41);
            this.txt_Device.Name = "txt_Device";
            this.txt_Device.Size = new System.Drawing.Size(115, 20);
            this.txt_Device.TabIndex = 13;
            this.txt_Device.Text = "PLC_1";
            // 
            // btn_Save
            // 
            this.btn_Save.Enabled = false;
            this.btn_Save.Location = new System.Drawing.Point(38, 108);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(115, 36);
            this.btn_Save.TabIndex = 14;
            this.btn_Save.Text = "Save Project";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.SaveProject);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Type Device name";
            // 
            // grp_TIA
            // 
            this.grp_TIA.Controls.Add(this.rdb_WithoutUI);
            this.grp_TIA.Controls.Add(this.rdb_WithUI);
            this.grp_TIA.Controls.Add(this.btn_Dispose);
            this.grp_TIA.Controls.Add(this.btn_Start);
            this.grp_TIA.Location = new System.Drawing.Point(12, 12);
            this.grp_TIA.Name = "grp_TIA";
            this.grp_TIA.Size = new System.Drawing.Size(185, 203);
            this.grp_TIA.TabIndex = 16;
            this.grp_TIA.TabStop = false;
            this.grp_TIA.Text = "TIA Portal";
            // 
            // rdb_WithoutUI
            // 
            this.rdb_WithoutUI.AutoSize = true;
            this.rdb_WithoutUI.Location = new System.Drawing.Point(36, 51);
            this.rdb_WithoutUI.Name = "rdb_WithoutUI";
            this.rdb_WithoutUI.Size = new System.Drawing.Size(132, 17);
            this.rdb_WithoutUI.TabIndex = 2;
            this.rdb_WithoutUI.Text = "Without User Interface";
            this.rdb_WithoutUI.UseVisualStyleBackColor = true;
            // 
            // rdb_WithUI
            // 
            this.rdb_WithUI.AutoSize = true;
            this.rdb_WithUI.Checked = true;
            this.rdb_WithUI.Location = new System.Drawing.Point(36, 28);
            this.rdb_WithUI.Name = "rdb_WithUI";
            this.rdb_WithUI.Size = new System.Drawing.Size(117, 17);
            this.rdb_WithUI.TabIndex = 1;
            this.rdb_WithUI.TabStop = true;
            this.rdb_WithUI.Text = "With User Interface";
            this.rdb_WithUI.UseVisualStyleBackColor = true;
            // 
            // grp_Compile
            // 
            this.grp_Compile.Controls.Add(this.label1);
            this.grp_Compile.Controls.Add(this.txt_Device);
            this.grp_Compile.Controls.Add(this.btn_CompileHW);
            this.grp_Compile.Location = new System.Drawing.Point(586, 12);
            this.grp_Compile.Name = "grp_Compile";
            this.grp_Compile.Size = new System.Drawing.Size(185, 203);
            this.grp_Compile.TabIndex = 17;
            this.grp_Compile.TabStop = false;
            this.grp_Compile.Text = "Compile";
            // 
            // grp_Project
            // 
            this.grp_Project.Controls.Add(this.btn_Connect);
            this.grp_Project.Controls.Add(this.btn_Save);
            this.grp_Project.Controls.Add(this.btn_CloseProject);
            this.grp_Project.Controls.Add(this.btn_SearchProject);
            this.grp_Project.Location = new System.Drawing.Point(203, 12);
            this.grp_Project.Name = "grp_Project";
            this.grp_Project.Size = new System.Drawing.Size(185, 203);
            this.grp_Project.TabIndex = 18;
            this.grp_Project.TabStop = false;
            this.grp_Project.Text = "Project";
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(38, 65);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(115, 36);
            this.btn_Connect.TabIndex = 5;
            this.btn_Connect.Text = "Connect to open TIA Project";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.btn_ConnectTIA);
            // 
            // btn_AddHW
            // 
            this.btn_AddHW.Enabled = false;
            this.btn_AddHW.Location = new System.Drawing.Point(431, 159);
            this.btn_AddHW.Name = "btn_AddHW";
            this.btn_AddHW.Size = new System.Drawing.Size(115, 36);
            this.btn_AddHW.TabIndex = 12;
            this.btn_AddHW.Text = "Add Device";
            this.btn_AddHW.UseVisualStyleBackColor = true;
            this.btn_AddHW.Click += new System.EventHandler(this.btn_AddHW_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_Version);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txt_OrderNo);
            this.groupBox1.Location = new System.Drawing.Point(395, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(185, 203);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Type Version";
            // 
            // txt_Version
            // 
            this.txt_Version.Location = new System.Drawing.Point(35, 122);
            this.txt_Version.Name = "txt_Version";
            this.txt_Version.Size = new System.Drawing.Size(115, 20);
            this.txt_Version.TabIndex = 21;
            this.txt_Version.Text = "V2.1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Type Order Nr";
            // 
            // txt_OrderNo
            // 
            this.txt_OrderNo.Location = new System.Drawing.Point(36, 82);
            this.txt_OrderNo.Name = "txt_OrderNo";
            this.txt_OrderNo.Size = new System.Drawing.Size(115, 20);
            this.txt_OrderNo.TabIndex = 19;
            this.txt_OrderNo.Text = "6ES7 516-3AN01-0AB0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Type Device name";
            // 
            // txt_AddDevice
            // 
            this.txt_AddDevice.Location = new System.Drawing.Point(431, 54);
            this.txt_AddDevice.Name = "txt_AddDevice";
            this.txt_AddDevice.Size = new System.Drawing.Size(115, 20);
            this.txt_AddDevice.TabIndex = 13;
            this.txt_AddDevice.Text = "PLC_1";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(99, 20);
            this.textBox1.TabIndex = 19;
            // 
            // button_BrowsAML
            // 
            this.button_BrowsAML.Location = new System.Drawing.Point(111, 39);
            this.button_BrowsAML.Name = "button_BrowsAML";
            this.button_BrowsAML.Size = new System.Drawing.Size(75, 23);
            this.button_BrowsAML.TabIndex = 20;
            this.button_BrowsAML.Text = "Brows_AML";
            this.button_BrowsAML.UseVisualStyleBackColor = true;
            this.button_BrowsAML.Click += new System.EventHandler(this.button_Brows_Click);
            // 
            // button_AddEplan
            // 
            this.button_AddEplan.Location = new System.Drawing.Point(45, 371);
            this.button_AddEplan.Name = "button_AddEplan";
            this.button_AddEplan.Size = new System.Drawing.Size(75, 23);
            this.button_AddEplan.TabIndex = 21;
            this.button_AddEplan.Text = "Add Eplan";
            this.button_AddEplan.UseVisualStyleBackColor = true;
            this.button_AddEplan.Click += new System.EventHandler(this.button_AddEplan_Click);
            // 
            // label_Eplan
            // 
            this.label_Eplan.AutoSize = true;
            this.label_Eplan.Location = new System.Drawing.Point(6, 25);
            this.label_Eplan.Name = "label_Eplan";
            this.label_Eplan.Size = new System.Drawing.Size(66, 13);
            this.label_Eplan.TabIndex = 22;
            this.label_Eplan.Text = "Import Eplan";
            this.label_Eplan.Click += new System.EventHandler(this.label5_Click);
            // 
            // label_FolderName
            // 
            this.label_FolderName.AutoSize = true;
            this.label_FolderName.Location = new System.Drawing.Point(8, 64);
            this.label_FolderName.Name = "label_FolderName";
            this.label_FolderName.Size = new System.Drawing.Size(67, 13);
            this.label_FolderName.TabIndex = 23;
            this.label_FolderName.Text = "Folder Name";
            // 
            // txtBox_FolderName
            // 
            this.txtBox_FolderName.Location = new System.Drawing.Point(81, 61);
            this.txtBox_FolderName.Name = "txtBox_FolderName";
            this.txtBox_FolderName.Size = new System.Drawing.Size(100, 20);
            this.txtBox_FolderName.TabIndex = 24;
            // 
            // button_CreateFolder
            // 
            this.button_CreateFolder.Location = new System.Drawing.Point(192, 59);
            this.button_CreateFolder.Name = "button_CreateFolder";
            this.button_CreateFolder.Size = new System.Drawing.Size(75, 23);
            this.button_CreateFolder.TabIndex = 25;
            this.button_CreateFolder.Text = "Create";
            this.button_CreateFolder.UseVisualStyleBackColor = true;
            this.button_CreateFolder.Click += new System.EventHandler(this.button_CreateFolder_Click);
            // 
            // label_BlockName
            // 
            this.label_BlockName.AutoSize = true;
            this.label_BlockName.Location = new System.Drawing.Point(10, 98);
            this.label_BlockName.Name = "label_BlockName";
            this.label_BlockName.Size = new System.Drawing.Size(65, 13);
            this.label_BlockName.TabIndex = 26;
            this.label_BlockName.Text = "Block Name";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(81, 95);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 24;
            // 
            // button_AddBlock
            // 
            this.button_AddBlock.Location = new System.Drawing.Point(192, 93);
            this.button_AddBlock.Name = "button_AddBlock";
            this.button_AddBlock.Size = new System.Drawing.Size(75, 23);
            this.button_AddBlock.TabIndex = 25;
            this.button_AddBlock.Text = "Add Block";
            this.button_AddBlock.UseVisualStyleBackColor = true;
            this.button_AddBlock.Click += new System.EventHandler(this.button_AddBlock_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_BrowsLog);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.label_Eplan);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.button_BrowsAML);
            this.groupBox2.Location = new System.Drawing.Point(39, 278);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(226, 100);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // button_BrowsLog
            // 
            this.button_BrowsLog.Location = new System.Drawing.Point(111, 65);
            this.button_BrowsLog.Name = "button_BrowsLog";
            this.button_BrowsLog.Size = new System.Drawing.Size(75, 23);
            this.button_BrowsLog.TabIndex = 23;
            this.button_BrowsLog.Text = "Brows_Log";
            this.button_BrowsLog.UseVisualStyleBackColor = true;
            this.button_BrowsLog.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(6, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(99, 20);
            this.textBox2.TabIndex = 23;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listView1);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.button1_2);
            this.groupBox3.Controls.Add(this.textBox4_2);
            this.groupBox3.Controls.Add(this.button_Export);
            this.groupBox3.Controls.Add(this.textBox_ExportName);
            this.groupBox3.Controls.Add(this.button_SearchFile);
            this.groupBox3.Controls.Add(this.button_Import);
            this.groupBox3.Controls.Add(this.label_FolderName);
            this.groupBox3.Controls.Add(this.txtBox_FolderName);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.label_BlockName);
            this.groupBox3.Controls.Add(this.button_CreateFolder);
            this.groupBox3.Controls.Add(this.button_AddBlock);
            this.groupBox3.Location = new System.Drawing.Point(261, 278);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(512, 209);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Folder Name2";
            // 
            // button1_2
            // 
            this.button1_2.Location = new System.Drawing.Point(192, 20);
            this.button1_2.Name = "button1_2";
            this.button1_2.Size = new System.Drawing.Size(75, 23);
            this.button1_2.TabIndex = 37;
            this.button1_2.Text = "Create";
            this.button1_2.UseVisualStyleBackColor = true;
            this.button1_2.Click += new System.EventHandler(this.button1_2_Click);
            // 
            // textBox4_2
            // 
            this.textBox4_2.Location = new System.Drawing.Point(86, 21);
            this.textBox4_2.Name = "textBox4_2";
            this.textBox4_2.Size = new System.Drawing.Size(100, 20);
            this.textBox4_2.TabIndex = 36;
            // 
            // button_Export
            // 
            this.button_Export.Location = new System.Drawing.Point(192, 173);
            this.button_Export.Name = "button_Export";
            this.button_Export.Size = new System.Drawing.Size(79, 21);
            this.button_Export.TabIndex = 32;
            this.button_Export.Text = "Export";
            this.button_Export.UseVisualStyleBackColor = true;
            this.button_Export.Click += new System.EventHandler(this.button_Export_Click);
            // 
            // textBox_ExportName
            // 
            this.textBox_ExportName.Location = new System.Drawing.Point(76, 173);
            this.textBox_ExportName.Name = "textBox_ExportName";
            this.textBox_ExportName.Size = new System.Drawing.Size(100, 20);
            this.textBox_ExportName.TabIndex = 35;
            // 
            // button_SearchFile
            // 
            this.button_SearchFile.Location = new System.Drawing.Point(76, 144);
            this.button_SearchFile.Name = "button_SearchFile";
            this.button_SearchFile.Size = new System.Drawing.Size(75, 23);
            this.button_SearchFile.TabIndex = 33;
            this.button_SearchFile.Text = "Search";
            this.button_SearchFile.UseVisualStyleBackColor = true;
            this.button_SearchFile.Click += new System.EventHandler(this.button_SearchFile_Click);
            // 
            // button_Import
            // 
            this.button_Import.Location = new System.Drawing.Point(192, 144);
            this.button_Import.Name = "button_Import";
            this.button_Import.Size = new System.Drawing.Size(75, 23);
            this.button_Import.TabIndex = 31;
            this.button_Import.Text = "Import";
            this.button_Import.UseVisualStyleBackColor = true;
            this.button_Import.Click += new System.EventHandler(this.button_Import_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 422);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Export Eplan";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // textBox_EplanExport
            // 
            this.textBox_EplanExport.Location = new System.Drawing.Point(48, 438);
            this.textBox_EplanExport.Name = "textBox_EplanExport";
            this.textBox_EplanExport.Size = new System.Drawing.Size(194, 20);
            this.textBox_EplanExport.TabIndex = 23;
            // 
            // button_EplanExport
            // 
            this.button_EplanExport.Location = new System.Drawing.Point(48, 464);
            this.button_EplanExport.Name = "button_EplanExport";
            this.button_EplanExport.Size = new System.Drawing.Size(75, 23);
            this.button_EplanExport.TabIndex = 24;
            this.button_EplanExport.Text = "Export";
            this.button_EplanExport.UseVisualStyleBackColor = true;
            this.button_EplanExport.Click += new System.EventHandler(this.button_EplanExport_Click);
            // 
            // listView1
            // 
            this.listView1.Activation = System.Windows.Forms.ItemActivation.TwoClick;
            this.listView1.CheckBoxes = true;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(286, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(191, 193);
            this.listView1.TabIndex = 39;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "File Path";
            this.columnHeader1.Width = 300;
            // 
            // remove
            // 
            this.remove.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.removeSelectedFileToolStripMenuItem});
            this.remove.Name = "contextMenuStrip1";
            this.remove.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.remove.Size = new System.Drawing.Size(183, 26);
            this.remove.Opening += new System.ComponentModel.CancelEventHandler(this.remove_Opening);
            // 
            // removeSelectedFileToolStripMenuItem
            // 
            this.removeSelectedFileToolStripMenuItem.Checked = true;
            this.removeSelectedFileToolStripMenuItem.CheckOnClick = true;
            this.removeSelectedFileToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.removeSelectedFileToolStripMenuItem.Name = "removeSelectedFileToolStripMenuItem";
            this.removeSelectedFileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.removeSelectedFileToolStripMenuItem.Text = "Remove selected file";
            this.removeSelectedFileToolStripMenuItem.Click += new System.EventHandler(this.removeSelectedFileToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(784, 499);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button_AddEplan);
            this.Controls.Add(this.textBox_EplanExport);
            this.Controls.Add(this.button_EplanExport);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_AddDevice);
            this.Controls.Add(this.grp_Project);
            this.Controls.Add(this.btn_AddHW);
            this.Controls.Add(this.grp_Compile);
            this.Controls.Add(this.grp_TIA);
            this.Controls.Add(this.txt_Status);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Openness_Start";
            this.grp_TIA.ResumeLayout(false);
            this.grp_TIA.PerformLayout();
            this.grp_Compile.ResumeLayout(false);
            this.grp_Compile.PerformLayout();
            this.grp_Project.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.remove.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.Button btn_Dispose;
        private System.Windows.Forms.Button btn_SearchProject;
        private System.Windows.Forms.TextBox txt_Status;
        private System.Windows.Forms.Button btn_CloseProject;
        private System.Windows.Forms.Button btn_CompileHW;
        private System.Windows.Forms.TextBox txt_Device;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grp_TIA;
        private System.Windows.Forms.RadioButton rdb_WithoutUI;
        private System.Windows.Forms.RadioButton rdb_WithUI;
        private System.Windows.Forms.GroupBox grp_Compile;
        private System.Windows.Forms.GroupBox grp_Project;
        private System.Windows.Forms.Button btn_AddHW;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_AddDevice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_OrderNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_Version;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button_BrowsAML;
        private System.Windows.Forms.Button button_AddEplan;
        private System.Windows.Forms.Label label_Eplan;
        private System.Windows.Forms.Label label_FolderName;
        private System.Windows.Forms.TextBox txtBox_FolderName;
        private System.Windows.Forms.Button button_CreateFolder;
        private System.Windows.Forms.Label label_BlockName;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button_AddBlock;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button_Import;
        private System.Windows.Forms.Button button_Export;
        private System.Windows.Forms.Button button_SearchFile;
        private System.Windows.Forms.TextBox textBox_ExportName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_EplanExport;
        private System.Windows.Forms.Button button_EplanExport;
        private System.Windows.Forms.Button button_BrowsLog;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1_2;
        private System.Windows.Forms.TextBox textBox4_2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ContextMenuStrip remove;
        private System.Windows.Forms.ToolStripMenuItem removeSelectedFileToolStripMenuItem;
    }
}

